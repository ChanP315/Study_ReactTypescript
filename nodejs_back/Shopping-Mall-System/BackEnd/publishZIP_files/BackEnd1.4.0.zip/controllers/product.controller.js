import Product from './model/Product.js'

const productController = {}

productController.createProduct = async(req, res) => {
    try
    {
        const {sku, name, size, image, category, description, price, stock, status} = req.body;
        const product = new Product({sku, name, size, image, category, description, price, stock, status});

        await product.save();

        console.log("createProduct Success");
        res.status(200).json({status: "createProduct Success", product});
    }catch(err)
    {
        console.log("createProduct Fail");
        res.status(400).json({status: "createProduct Fail", error: err.message});
    }
}

productController.getProducts = async(req, res) => {
    try
    {
        const products = await Product.find({});

        console.log("getProducts Success");
        res.status(200).json({status: "getProducts Success", products});
    }catch(err)
    {
        console.log("getProducts Fail");
        res.status(400).json({status: "getProducts Fail", error: err.message});
    }
}

export default productController;